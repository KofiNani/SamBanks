<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admin_sidebar_style.css">
</head>

<body>
    <div class="sidenav" id="theSideNav">
        <a href="javascript:void(0)" id="closebtn" style="padding: 10px 20px;"
                        onclick="closeNav()">&times;</a>
        <a href="./customer_home.php">Home</a>
        <a href="./customer_transactions.php">My Transactions</a>
        <a id="label">New Transaction</a>
        <a href="./cred_debit.php">Withdraw/Deposit</a>
        <a id="label">Contact Us</a>
        <a href="#">Complaints</a>
    </div>

</body>
</html>
