<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="admin_sidebar_style.css">
</head>

<body>
    <div class="sidenav" id="theSideNav">
        <a href="javascript:void(0)" id="closebtn" onclick="closeNav()">&times;</a>
        <a href="./admin_home.php">Home</a>
        <a id="label">My Customers</a>
        <a href="./add_user.php">Add Customer</a>
        <a href="./manage_customers.php">Manage Customers</a>
        <a href="#h">Complaints</a>
        <a id="label">Website Management</a>
        <a href="./post_news.php">News Updates</a>
    </div>


</body>
</html>
