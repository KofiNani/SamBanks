<?php
    include "header.php";
    include "navbar.php";
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="contact_style.css">
</head>

<body>
    <div class="flex-container-background">
        <div class="flex-container-heading">
            <h1 id="contact">Contact Us</h1>
        </div>

        <div class="flex-container" style="border-bottom: 0;
                                           border-top-left-radius: 10px;
                                           border-top-right-radius: 10px;">
            <div class="flex-item">
                <h1 id="sub-contact">Location</h1>
                <p id="sub-contact">
                    Ghana Post GPS:<br>GA-0120-1901<br>
                    1 University Avenue, Berekuso, Eastern Region<br>
                    
                </p>
            </div>
            <div class="flex-item">
                <h1 id="sub-contact">General Contact</h1>
                <p id="sub-contact">
                    Phone: +233-54-629-4043<br>
                    Email: Sambanks@gmail.com
                </p>
            </div>
        </div>
           
        </div>
    </div>

</body>
</html>
